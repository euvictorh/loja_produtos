from django.contrib import admin
from .models import Cliente, Produto, Venda
from django.utils.translation import gettext_lazy as _

class VendaAdmin(admin.ModelAdmin):
    list_display = ('cliente', 'produto', 'quantidade', 'data_venda', 'valor_total')
    list_filter = ('cliente', 'data_venda')  # Filtros por cliente e data da venda
    search_fields = ('cliente__nome', 'produto__nome')  # Busca por nome do cliente ou nome do produto

# Registrando os modelos com a classe customizada do admin
admin.site.register(Cliente)
admin.site.register(Produto)
admin.site.register(Venda, VendaAdmin)
